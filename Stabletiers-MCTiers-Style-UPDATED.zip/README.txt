STABLETIERS

Dieses Paket enthält:
- Stabletiers-Website/ — responsive Minecraft-Tierlist im Stil der bereitgestellten Referenzbilder
- Stabletiers-Minecraft/ — vorhandenes Paper-Plugin
- Stabletiers-ResourcePack/ — vorhandene Icons

NEU AUF DER WEBSITE
- Mobile Header + Suchfeld
- Slide-out Menü mit Home, Rankings, API Docs und Discord-Kacheln
- PvP-Gamemode-Leiste
- MCTiers-inspirierte Spieler-/Tierkarten
- Spielerprofile
- Ränge-Menü: über Menü > „Ränge verwalten“ können Website-Ränge vergeben/entfernt werden
- Ränge werden im Browser per localStorage gespeichert

WICHTIG ZU RÄNGEN
Die mitgelieferte Rangverwaltung ist eine Frontend-Demo. Für eine echte öffentliche Website mit mehreren Benutzern muss die Rangvergabe über einen geschützten Backend-API-Endpunkt + Login/Session gespeichert werden. Ein Passwort direkt in JavaScript wäre nicht sicher.

START
Die Website kann direkt geöffnet werden: Stabletiers-Website/index.html
Für lokale Entwicklung ist z.B. ein einfacher Static-Server sinnvoll.

Hinweis: Das Design ist eine eigenständige Stabletiers-Umsetzung, die sich an den hochgeladenen Referenz-Screenshots orientiert. MCTiers-Branding und proprietärer Quellcode werden nicht kopiert.
