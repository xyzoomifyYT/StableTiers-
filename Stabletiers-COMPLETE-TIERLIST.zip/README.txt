STABLETIERS – COMPLETE TIERLIST

Enthalten:
- Stabletiers-Website/ – vollständige Website + Node.js Backend
- Admin-Login mit serverseitiger Session
- Spieler hinzufügen/bearbeiten/löschen
- Website-Ränge: User, Tester, Media, Helper, Moderator, Admin, Owner
- Tier für UHC, Pot, NethOP, SMP, Sword, Axe, Mace und Crystal setzen
- Ranking-Sortierung nach gewähltem Gamemode
- Suche, Spielerprofile, mobile Navigation, Discords, Server-IP Copy
- Öffentliche API: /api/data, /api/players, /api/players/:name
- data.json als persistente Datenbank für die Demo/kleine Website
- Stabletiers-Minecraft/ – vorhandenes Paper-Plugin
- Stabletiers-ResourcePack/ – vorhandene Icons

START:
1. Node.js 18+ installieren.
2. In Stabletiers-Website wechseln.
3. ADMIN_PASSWORD auf ein eigenes Passwort setzen.
4. node server.js starten.
5. http://localhost:3000 öffnen.

WICHTIG:
Die Website ist eine eigenständige Umsetzung nach den hochgeladenen Referenzbildern. MCTiers-Quellcode wird nicht kopiert.
