package net.stabletier.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class StableTierPlugin extends JavaPlugin {
    private Scoreboard board;
    private static final LinkedHashMap<String, String> MODES = new LinkedHashMap<>();
    static {
        MODES.put("crystal", "\uE001");
        MODES.put("pearl",  "\uE002");
        MODES.put("mace",   "\uE003");
        MODES.put("armor",  "\uE004");
        MODES.put("sword",  "\uE005");
        MODES.put("pot",    "\uE006");
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        board = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Player p : Bukkit.getOnlinePlayers()) updatePlayer(p);
        Bukkit.getPluginManager().registerEvents(new StableTierListener(this), this);
        getLogger().info("StableTier 2.0 enabled.");
    }

    public Map<String,String> getModes(Player p) { return getModes(p.getName()); }
    public Map<String,String> getModes(String name) {
        LinkedHashMap<String,String> out = new LinkedHashMap<>();
        ConfigurationSection sec = getConfig().getConfigurationSection("players."+name+".modes");
        if (sec != null) for (String mode : MODES.keySet()) out.put(mode, sec.getString(mode, "NA").toUpperCase(Locale.ROOT));
        return out;
    }
    public String getOverall(Player p) { return getConfig().getString("players."+p.getName()+".overall", bestTier(getModes(p))).toUpperCase(Locale.ROOT); }
    private String bestTier(Map<String,String> m) {
        String best="NA"; int score=999;
        for(String t:m.values()) { int s=tierScore(t); if(s<score){score=s;best=t;} }
        return best;
    }
    private int tierScore(String t){
        if(t==null)return 999; t=t.toUpperCase(Locale.ROOT);
        try { String x=t.substring(2); int n=Integer.parseInt(x); return (t.startsWith("HT")?0:10)+n; } catch(Exception e){return 999;}
    }
    public void setModeTier(String player, String mode, String tier) {
        mode=normalizeMode(mode); tier=tier.toUpperCase(Locale.ROOT);
        getConfig().set("players."+player+".modes."+mode, tier);
        if(!getConfig().contains("players."+player+".overall")) getConfig().set("players."+player+".overall", tier);
        saveConfig(); refresh(player);
    }
    public void removeModeTier(String player,String mode){ getConfig().set("players."+player+".modes."+normalizeMode(mode),null); saveConfig(); refresh(player); }
    private void refresh(String name){ Player p=Bukkit.getPlayerExact(name); if(p!=null)updatePlayer(p); }
    public String normalizeMode(String mode){ mode=mode.toLowerCase(Locale.ROOT); if(mode.equals("crystal"))return "crystal"; if(mode.equals("pearl")||mode.equals("enderpearl"))return "pearl"; if(mode.equals("mace"))return "mace"; if(mode.equals("armor")||mode.equals("armour"))return "armor"; if(mode.equals("sword"))return "sword"; if(mode.equals("pot")||mode.equals("potion"))return "pot"; return mode; }
    public String icon(String mode){ return MODES.getOrDefault(normalizeMode(mode), ""); }
    public String modeLabel(String mode){ return switch(normalizeMode(mode)){case "crystal"->"Crystal";case "pearl"->"Pearl";case "mace"->"Mace";case "armor"->"Armor";case "sword"->"Sword";case "pot"->"Pot";default->mode;}; }
    /** Returns the single highest tier the player has, together with its mode.
     *  HT1 is higher than HT2, and any HT tier is higher than any LT tier.
     *  If several modes have the same highest tier, the first mode in the StableTier
     *  mode order is used so only one icon/tier is shown in Minecraft.
     */
    public Map.Entry<String,String> getHighestModeTier(Player p) {
        Map<String,String> modes=getModes(p);
        String bestMode=null, bestTier="NA";
        int best=999;
        for (String mode : MODES.keySet()) {
            String tier=modes.getOrDefault(mode,"NA");
            int score=tierScore(tier);
            if(score<best){ best=score; bestMode=mode; bestTier=tier; }
        }
        return new java.util.AbstractMap.SimpleEntry<>(bestMode,bestTier);
    }

    public void updatePlayer(Player p){
        Map.Entry<String,String> highest=getHighestModeTier(p);
        String tier=highest.getValue();
        String mode=highest.getKey();
        String label=(mode==null?"":icon(mode)+" ")+colorTier(tier);
        if(getConfig().getBoolean("display.tab",true)) p.setPlayerListName(label+" "+ChatColor.WHITE+p.getName()); else p.setPlayerListName(p.getName());
        if(getConfig().getBoolean("display.nametag",true)){
            Team team=getOrCreateTeam(tier, mode);
            for(Team t:board.getTeams()) if(t.getName().startsWith("st_")) t.removeEntry(p.getName());
            team.addEntry(p.getName());
        }
    }
    private Team getOrCreateTeam(String tier, String mode){
        String safe=tier.replaceAll("[^A-Za-z0-9_]","");
        if(safe.isBlank())safe="NA";
        String modeSafe=(mode==null?"none":normalizeMode(mode)).replaceAll("[^A-Za-z0-9_]","");
        String teamName="st_"+safe+"_"+modeSafe;
        if(teamName.length()>64) teamName=teamName.substring(0,64);
        Team team=board.getTeam(teamName);
        if(team==null)team=board.registerNewTeam(teamName);
        team.setPrefix((mode==null?"":icon(mode)+" ")+colorTier(tier)+" ");
        return team;
    }
    public String colorTier(String tier){ String t=tier.toUpperCase(Locale.ROOT); ChatColor c=switch(t){case "HT1"->ChatColor.GOLD;case "HT2"->ChatColor.YELLOW;case "HT3"->ChatColor.GREEN;case "HT4"->ChatColor.AQUA;case "LT1"->ChatColor.LIGHT_PURPLE;case "LT2"->ChatColor.BLUE;case "LT3"->ChatColor.DARK_AQUA;case "LT4"->ChatColor.GRAY;default->ChatColor.RED;}; return c+"["+t+"]"; }
    public void sendProfile(CommandSender s, String name){
        Map<String,String> m=getModes(name); s.sendMessage(ChatColor.GOLD+"=== StableTier: "+name+" ===");
        for(var e:m.entrySet()) s.sendMessage(icon(e.getKey())+" "+ChatColor.WHITE+modeLabel(e.getKey())+": "+colorTier(e.getValue()));
        s.sendMessage(ChatColor.GRAY+"Overall: "+colorTier(getConfig().getString("players."+name+".overall",bestTier(m))));
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a){
        if(!cmd.getName().equalsIgnoreCase("tier"))return false;
        if(a.length==0 || a[0].equalsIgnoreCase("profile")) { String n=a.length>=2?a[1]:(sender instanceof Player p?p.getName():null); if(n==null){sender.sendMessage("/tier profile <player>");return true;} sendProfile(sender,n); return true; }
        if(a[0].equalsIgnoreCase("get")){ String n=a.length>=2?a[1]:(sender instanceof Player p?p.getName():null); if(n==null){sender.sendMessage("/tier get <player>");return true;} sendProfile(sender,n); return true; }
        if(!sender.hasPermission("stabletier.admin")){sender.sendMessage(ChatColor.RED+"No permission.");return true;}
        if(a[0].equalsIgnoreCase("set") && a.length>=4){setModeTier(a[1],a[2],a[3]);sender.sendMessage(ChatColor.GREEN+"Set "+a[1]+" "+modeLabel(a[2])+" to "+colorTier(a[3]));return true;}
        if(a[0].equalsIgnoreCase("remove") && a.length>=3){removeModeTier(a[1],a[2]);sender.sendMessage(ChatColor.GREEN+"Removed "+modeLabel(a[2])+" for "+a[1]);return true;}
        if(a[0].equalsIgnoreCase("reload")){reloadConfig();for(Player p:Bukkit.getOnlinePlayers())updatePlayer(p);sender.sendMessage(ChatColor.GREEN+"StableTier reloaded.");return true;}
        sender.sendMessage(ChatColor.YELLOW+"/tier profile [player]"); sender.sendMessage(ChatColor.YELLOW+"/tier set <player> <crystal|pearl|mace|armor|sword|pot> <HT1..LT4>"); sender.sendMessage(ChatColor.YELLOW+"/tier remove <player> <mode>"); sender.sendMessage(ChatColor.YELLOW+"/tier reload"); return true;
    }
}
