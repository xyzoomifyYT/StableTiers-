package net.stabletier.plugin;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.entity.Player;
import java.util.Map;
public final class StableTierListener implements Listener {
 private final StableTierPlugin plugin; public StableTierListener(StableTierPlugin plugin){this.plugin=plugin;}
 @EventHandler public void onJoin(PlayerJoinEvent e){Player p=e.getPlayer(); plugin.updatePlayer(p); if(plugin.getConfig().getBoolean("display.joinMessage",true)){p.sendMessage(ChatColor.GOLD+"StableTier "+ChatColor.GRAY+"- "+plugin.colorTier(plugin.getOverall(p))); for(Map.Entry<String,String> x:plugin.getModes(p).entrySet()) p.sendMessage(plugin.icon(x.getKey())+" "+ChatColor.WHITE+plugin.modeLabel(x.getKey())+": "+plugin.colorTier(x.getValue()));}}
}
